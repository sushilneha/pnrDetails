package com.ba.pnrdetails.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.ba.pnrdetails.entity.PnrDetails;
import com.ba.pnrdetails.service.PnrDetailsService;

@RestController
public class PnrDetailsController {

	@Autowired
	private PnrDetailsService detailsService;
	
	@PostMapping("/savePnrDetails")
	public ResponseEntity<Object> savePnrDetails(@RequestBody PnrDetails pnrDetails) {
		
		PnrDetails savePnrDetails = detailsService.savePnrDetails(pnrDetails);
		System.out.println("savePnrDetails-->"+savePnrDetails.toString());
		URI uri = ServletUriComponentsBuilder
				.fromCurrentRequest()
				.path("/{id}")
				.buildAndExpand(savePnrDetails.getId()).toUri();
		return ResponseEntity.created(uri).build();
	}
	
	@GetMapping("/getPnrDetails/{pnr}")
	public PnrDetails getPnrDetails(@PathVariable String pnr) {
		return detailsService.getPnrDetails(pnr);
	}
}
