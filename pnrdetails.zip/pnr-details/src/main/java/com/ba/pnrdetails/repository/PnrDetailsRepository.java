package com.ba.pnrdetails.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ba.pnrdetails.entity.PnrDetails;
@Repository
public interface PnrDetailsRepository extends JpaRepository<PnrDetails, Long> {
 
	PnrDetails findByPnr(String pnr);
}
