package com.ba.pnrdetails.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ba.pnrdetails.entity.PnrDetails;
import com.ba.pnrdetails.exception.PnrDetailsNotFoundException;
import com.ba.pnrdetails.repository.PnrDetailsRepository;

@Service
public class PnrDetailsService {

	@Autowired
	private PnrDetailsRepository pnrDetailsRepository;

	public PnrDetails savePnrDetails(PnrDetails pnrDetails) {
		return pnrDetailsRepository.save(pnrDetails);
	}

	public PnrDetails getPnrDetails(String pnr) {
		Optional<PnrDetails> pnrDetails = Optional.ofNullable(pnrDetailsRepository.findByPnr(pnr));
		if (pnrDetails.isEmpty()) {
			throw new PnrDetailsNotFoundException("pnr:" + pnr);
		}
		return pnrDetails.get();
	}
}
