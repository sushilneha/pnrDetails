package com.ba.pnrdetails.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pnrdetails")
public class PnrDetails {

	@Id
	@GeneratedValue
	private Long id;
	private String pnr;
	@Column(name = "sur_name")
	private String surName;
	
	private String phone;
	private String email;
	private String execClub;
	private String destination;
	@Column(name = "alternative_required")
	private boolean alternativeRequired;
	@Column(name = "alternative_destination")
	private String alternativeDestination;
	@Column(name = "pnr_date")
	private Date date;
	@Column(name = "linked_ONR")
	private String linkedONR;
	@Column(name = "split_PNR")
	private boolean splitPNR;
	private String bagTagNumber;
	private boolean bagTag;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPnr() {
		return pnr;
	}
	public void setPnr(String pnr) {
		this.pnr = pnr;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getExecClub() {
		return execClub;
	}
	public void setExecClub(String execClub) {
		this.execClub = execClub;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public boolean isAlternativeRequired() {
		return alternativeRequired;
	}
	public void setAlternativeRequired(boolean alternativeRequired) {
		this.alternativeRequired = alternativeRequired;
	}
	public String getAlternativeDestination() {
		return alternativeDestination;
	}
	public void setAlternativeDestination(String alternativeDestination) {
		this.alternativeDestination = alternativeDestination;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getLinkedONR() {
		return linkedONR;
	}
	public void setLinkedONR(String linkedONR) {
		this.linkedONR = linkedONR;
	}
	public boolean isSplitPNR() {
		return splitPNR;
	}
	public void setSplitPNR(boolean splitPNR) {
		this.splitPNR = splitPNR;
	}
	public String getBagTagNumber() {
		return bagTagNumber;
	}
	public void setBagTagNumber(String bagTagNumber) {
		this.bagTagNumber = bagTagNumber;
	}
	public boolean isBagTag() {
		return bagTag;
	}
	public void setBagTag(boolean bagTag) {
		this.bagTag = bagTag;
	}
	@Override
	public String toString() {
		return "PnrDetails [id=" + id + ", pnr=" + pnr + ", surName=" + surName + ", phone=" + phone + ", email="
				+ email + ", execClub=" + execClub + ", destination=" + destination + ", alternativeRequired="
				+ alternativeRequired + ", alternativeDestination=" + alternativeDestination + ", date=" + date
				+ ", linkedONR=" + linkedONR + ", splitPNR=" + splitPNR + ", bagTagNumber=" + bagTagNumber + ", bagTag="
				+ bagTag + "]";
	}
	
	
}
