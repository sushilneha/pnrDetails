package com.ba.pnrdetails.bean;

import java.util.Date;

public class PnrDetailsBean {
	private String pnr;
	private String surName;
	private String phone;
	private String email;
	private String execClub;
	private String destination;
	private boolean alternativeRequired;
	private String alternativeDestination;
	private Date date;
	private String linkedONR;
	private boolean splitPNR;
	private String bagTagNumber;
	private boolean bagTag;
}
