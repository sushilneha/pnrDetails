package com.ba.pnrdetails.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class PnrDetailsNotFoundException extends RuntimeException{

	public PnrDetailsNotFoundException(String msg) {
		super(msg);
	}
}
