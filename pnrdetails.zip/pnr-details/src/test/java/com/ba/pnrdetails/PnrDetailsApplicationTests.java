package com.ba.pnrdetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PnrDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
